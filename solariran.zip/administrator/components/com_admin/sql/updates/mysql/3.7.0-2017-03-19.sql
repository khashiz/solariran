ALTER TABLE `#__finder_links` MODIFY `description` text;
